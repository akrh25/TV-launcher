package com.example.minilauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ResolveInfo
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections

class AppEntry(val pkg: String, val label: String, val info: ResolveInfo)

class VH(v: View) : RecyclerView.ViewHolder(v) {
    val icon: ImageView = v.findViewById(R.id.icon)
    val label: TextView = v.findViewById(R.id.label)
    val banner: ImageView? = v.findViewById(R.id.banner)
}

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: View
    private lateinit var favList: RecyclerView
    private lateinit var grid: RecyclerView
    private lateinit var favSection: View
    private lateinit var weatherView: TextView

    private val favAdapter = AppAdapter(R.layout.item_fav, true)
    private val gridAdapter = AppAdapter(R.layout.item_app, false)

    private var allApps: List<AppEntry> = emptyList()
    private val favs = mutableListOf<String>()
    private val order = mutableListOf<String>()
    private val hidden = mutableSetOf<String>()
    private var lastPkg: String? = null

    private val themes = listOf(
        intArrayOf(0xFF161A3A.toInt(), 0xFF05060B.toInt()),
        intArrayOf(0xFF0B2A3C.toInt(), 0xFF04101A.toInt()),
        intArrayOf(0xFF2A1740.toInt(), 0xFF0A0612.toInt()),
        intArrayOf(0xFF0E2A22.toInt(), 0xFF040D0A.toInt()),
        intArrayOf(0xFF1C1C1C.toInt(), 0xFF000000.toInt())
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)

        root = findViewById(R.id.root)
        favList = findViewById(R.id.fav_list)
        grid = findViewById(R.id.grid)
        favSection = findViewById(R.id.fav_section)
        weatherView = findViewById(R.id.weather)

        favList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        favList.adapter = favAdapter
        grid.layoutManager = GridLayoutManager(this, 6)
        grid.adapter = gridAdapter

        findViewById<View>(R.id.btn_live).setOnClickListener { openLiveTv() }
        findViewById<View>(R.id.btn_source).setOnClickListener { showSources() }
        findViewById<View>(R.id.btn_settings).setOnClickListener {
            if (!tryStart(Intent(Settings.ACTION_SETTINGS))) toast("Ayarlar açılamadı")
        }
        findViewById<View>(R.id.btn_bg).setOnClickListener { cycleTheme() }
        findViewById<View>(R.id.btn_hidden).setOnClickListener { showHidden() }

        applyTheme()
        loadState()
        loadWeather()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        refresh(null)
        val target = lastPkg
        if (target != null && inLists(target)) focusOn(target) else focusFirst()
    }

    // Ana ekranda geri tuşu bir şey yapmasın
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    // ---------- Durum ----------

    private fun loadState() {
        favs.clear()
        favs.addAll((prefs.getString("favs", "") ?: "").split("|").filter { it.isNotEmpty() })
        order.clear()
        order.addAll((prefs.getString("order", "") ?: "").split("|").filter { it.isNotEmpty() })
        hidden.clear()
        hidden.addAll(prefs.getStringSet("hidden", emptySet()) ?: emptySet())
    }

    private fun saveState() {
        prefs.edit()
            .putString("favs", favs.joinToString("|"))
            .putString("order", order.joinToString("|"))
            .putStringSet("hidden", HashSet(hidden))
            .apply()
    }

    private fun loadApps() {
        val pm = packageManager
        val tv = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val phone = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = (pm.queryIntentActivities(tv, 0) + pm.queryIntentActivities(phone, 0))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppEntry(it.activityInfo.packageName, it.loadLabel(pm).toString(), it) }
            .sortedBy { it.label.lowercase() }

        if (!prefs.getBoolean("init", false)) {
            val want = listOf("netflix", "disney", "youtube", "prime video", "exxen")
            for (w in want) {
                allApps.firstOrNull { it.label.lowercase().contains(w) && it.pkg !in favs }
                    ?.let { favs.add(it.pkg) }
            }
            allApps.filter { it.label.lowercase().startsWith("disclaimer") }
                .forEach { hidden.add(it.pkg) }
            saveState()
            prefs.edit().putBoolean("init", true).apply()
        }
    }

    // ---------- Listeleri güncelle ----------

    private fun refresh(focusPkg: String?) {
        val byPkg = allApps.associateBy { it.pkg }
        favs.retainAll { it in byPkg && it !in hidden }
        val favEntries = favs.mapNotNull { byPkg[it] }
        val gridEntries = allApps
            .filter { it.pkg !in hidden && it.pkg !in favs }
            .sortedWith(compareBy<AppEntry>({
                val i = order.indexOf(it.pkg)
                if (i < 0) Int.MAX_VALUE else i
            }, { it.label.lowercase() }))

        favAdapter.items = favEntries
        gridAdapter.items = gridEntries
        favAdapter.notifyDataSetChanged()
        gridAdapter.notifyDataSetChanged()
        favSection.visibility = if (favEntries.isEmpty()) View.GONE else View.VISIBLE
        if (focusPkg != null) focusOn(focusPkg)
    }

    private fun inLists(pkg: String): Boolean =
        favAdapter.items.any { it.pkg == pkg } || gridAdapter.items.any { it.pkg == pkg }

    private fun focusOn(pkg: String) {
        val fi = favAdapter.items.indexOfFirst { it.pkg == pkg }
        val rv: RecyclerView
        val pos: Int
        if (fi >= 0) {
            rv = favList; pos = fi
        } else {
            rv = grid; pos = gridAdapter.items.indexOfFirst { it.pkg == pkg }
        }
        if (pos < 0) return
        rv.scrollToPosition(pos)
        rv.postDelayed({ rv.findViewHolderForAdapterPosition(pos)?.itemView?.requestFocus() }, 250)
    }

    private fun focusFirst() {
        val first = favAdapter.items.firstOrNull() ?: gridAdapter.items.firstOrNull() ?: return
        focusOn(first.pkg)
    }

    // ---------- Uygulama menüsü (OK tuşuna basılı tut) ----------

    private fun showMenu(e: AppEntry, isFav: Boolean) {
        val opts = arrayOf(
            if (isFav) "Sık kullanılanlardan çıkar" else "Sık kullanılanlara ekle",
            "Gizle",
            "Öne taşı",
            "Geriye taşı"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(e.label)
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> {
                        if (isFav) favs.remove(e.pkg) else favs.add(e.pkg)
                        saveState(); refresh(e.pkg)
                    }
                    1 -> {
                        hidden.add(e.pkg); favs.remove(e.pkg)
                        saveState(); refresh(null); focusFirst()
                    }
                    2 -> move(e.pkg, isFav, -1)
                    3 -> move(e.pkg, isFav, 1)
                }
            }
            .show()
    }

    private fun move(pkg: String, isFav: Boolean, delta: Int) {
        val list: MutableList<String> = if (isFav) favs else {
            order.clear()
            order.addAll(gridAdapter.items.map { it.pkg })
            order
        }
        val i = list.indexOf(pkg)
        val j = i + delta
        if (i >= 0 && j >= 0 && j < list.size) {
            Collections.swap(list, i, j)
            saveState()
        }
        refresh(pkg)
    }

    private fun showHidden() {
        val list = allApps.filter { it.pkg in hidden }
        if (list.isEmpty()) { toast("Gizlenen uygulama yok"); return }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Gizlenenler (geri getirmek için seç)")
            .setItems(list.map { it.label }.toTypedArray()) { _, which ->
                hidden.remove(list[which].pkg)
                saveState(); refresh(list[which].pkg)
            }
            .show()
    }

    // ---------- Kısayollar ----------

    private fun tryStart(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        true
    } catch (e: Exception) {
        false
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun inputs(): List<TvInputInfo> = try {
        val tm = getSystemService(Context.TV_INPUT_SERVICE) as? TvInputManager
        tm?.tvInputList ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    private fun openLiveTv() {
        val tuner = inputs().firstOrNull { it.type == TvInputInfo.TYPE_TUNER }
        val tries = mutableListOf(Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI))
        if (tuner != null) {
            tries.add(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(tuner.id)))
        }
        if (tries.none { tryStart(it) }) toast("Canlı TV açılamadı")
    }

    private fun showSources() {
        val list = inputs().filter { it.isPassthroughInput }
        if (list.isEmpty()) { toast("Kaynak bulunamadı"); return }
        val names = list.map { (it.loadCustomLabel(this) ?: it.loadLabel(this)).toString() }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Kaynak seç")
            .setItems(names.toTypedArray()) { _, which ->
                val uri = TvContract.buildChannelUriForPassthroughInput(list[which].id)
                if (!tryStart(Intent(Intent.ACTION_VIEW, uri))) toast("Kaynak açılamadı")
            }
            .show()
    }

    // ---------- Arka plan ----------

    private fun applyTheme() {
        val c = themes[prefs.getInt("theme", 0) % themes.size]
        root.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, c)
    }

    private fun cycleTheme() {
        prefs.edit().putInt("theme", (prefs.getInt("theme", 0) + 1) % themes.size).apply()
        applyTheme()
    }

    // ---------- Hava durumu (Open-Meteo, anahtar gerekmez) ----------

    private fun loadWeather() {
        prefs.getString("w_text", null)?.let { weatherView.text = it }
        val last = prefs.getLong("w_time", 0L)
        if (System.currentTimeMillis() - last < 30 * 60 * 1000L) return
        Thread {
            try {
                var lat = prefs.getString("lat", null)
                var lon = prefs.getString("lon", null)
                if (lat == null || lon == null) {
                    val geo = JSONObject(httpGet("https://ipwho.is/"))
                    lat = geo.getDouble("latitude").toString()
                    lon = geo.getDouble("longitude").toString()
                    prefs.edit().putString("lat", lat).putString("lon", lon).apply()
                }
                val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code&timezone=auto"
                val cur = JSONObject(httpGet(url)).getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m")).toInt()
                val label = weatherLabel(cur.getInt("weather_code"))
                val text = if (label.isEmpty()) "$t°C" else "$t°C · $label"
                prefs.edit().putString("w_text", text)
                    .putLong("w_time", System.currentTimeMillis()).apply()
                runOnUiThread { weatherView.text = text }
            } catch (e: Exception) {
                // İnternet yoksa eski değer kalır
            }
        }.start()
    }

    private fun httpGet(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun weatherLabel(c: Int): String = when (c) {
        0 -> "Açık"
        1 -> "Çoğunlukla açık"
        2 -> "Parçalı bulutlu"
        3 -> "Kapalı"
        45, 48 -> "Sisli"
        in 51..57 -> "Çisenti"
        in 61..67 -> "Yağmurlu"
        in 71..77 -> "Karlı"
        in 80..82 -> "Sağanak yağmur"
        85, 86 -> "Kar sağanağı"
        in 95..99 -> "Gök gürültülü fırtına"
        else -> ""
    }

    // ---------- Adaptör ----------

    private inner class AppAdapter(private val layout: Int, private val fav: Boolean) :
        RecyclerView.Adapter<VH>() {

        var items: List<AppEntry> = emptyList()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val e = items[position]
            val pm = packageManager
            h.label.text = e.label

            val banner = if (fav) e.info.activityInfo.loadBanner(pm) else null
            val bannerView = h.banner
            if (bannerView != null && banner != null) {
                bannerView.setImageDrawable(banner)
                bannerView.visibility = View.VISIBLE
                h.icon.visibility = View.GONE
                h.label.visibility = View.GONE
            } else {
                bannerView?.visibility = View.GONE
                h.icon.setImageDrawable(e.info.loadIcon(pm))
                h.icon.visibility = View.VISIBLE
                h.label.visibility = View.VISIBLE
            }

            h.itemView.setOnClickListener {
                val i = Intent(Intent.ACTION_MAIN)
                    .setClassName(e.info.activityInfo.packageName, e.info.activityInfo.name)
                if (!tryStart(i)) toast("Uygulama açılamadı")
            }
            h.itemView.setOnLongClickListener { showMenu(e, fav); true }
            h.itemView.setOnFocusChangeListener { v, focused ->
                if (focused) lastPkg = e.pkg
                val s = if (focused) 1.07f else 1f
                v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            }
        }
    }
}
